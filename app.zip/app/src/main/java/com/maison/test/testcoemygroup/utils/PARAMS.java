package com.maison.test.testcoemygroup.utils;

/**
 * Created by Christophe on 02/06/2016.
 */
public class PARAMS {

    static final String WS_ADR_HEROES_URI = "http://coemygroup.fr/test-mobile/iOS/json/test3.json";
}
